<?php
	session_start();
	if(!isset($_SESSION["ty"]))
	header("location:logout.php");
	$con=new mysqli('localhost','root','',"ding");
	
	$mdl=$_GET['val'];
	$_SESSION['mdl']=$mdl;
	$tn=$_SESSION['cn'].'_'.$mdl.'_cnt';
	$ts=$_SESSION['cn'].'_std';
	
?>

<html>
    <head>
       <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
	   <link rel="stylesheet" href="css/w3m.css">
	     <link rel="stylesheet" href="css/w3.css">
       <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	
      <script type="text/javascript" src="js/materialize.min.js"></script>
	  <script type="text/javascript" src="js/materialize.js"></script>
	  
	  
<script>
function myFunction(id) {
    var x = document.getElementById(id);
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}
</script>
	
  </head>
    <body>
<?php
if(isset($_POST['qui']))
{
		$_SESSION["qn"]=$_POST['qui'];
		header("location:modules.php");

}

if(isset($_POST['quilve']))
{
		$_SESSION["qn"]=$_POST['quilve'];
		header("location:swift.php");

}

if(isset($_POST['qui']))
{
		$_SESSION["qn"]=$_POST['qui'];
		header("location:modules.php");

}

if(isset($_POST['quil']))
{
	$sql = "update $tn set pub=1 where qname='$_POST[quil]'";
    if (!$con->query($sql) == TRUE) 
			echo "Error del: " . $con->connect_error;
}

if(isset($_POST['quillve']))
{
	$sql = "update $tn set pub=1 where qname='$_POST[quillve]'";
    if (!$con->query($sql) == TRUE) 
			echo "Error del: " . $con->connect_error;
	$sql = "insert into swift (ccode,mdl,que) values('$_SESSION[cn]','$mdl','$_POST[quillve]')";
	 if (!$con->query($sql) == TRUE) 
			echo "Error lnch: " . $con->connect_error;
}

if(isset($_POST['quih']))
{
	$sql = "update $tn set pub=0 where qname='$_POST[quih]'";
    if (!$con->query($sql) == TRUE) 
			echo "Error del: " . $con->connect_error;
	$sql = "delete from swift where ccode='$_SESSION[cn]' and mdl='$mdl' and que='$_POST[quih]'";
	if (!$con->query($sql) == TRUE) 
			echo "Error hide: " . $con->connect_error;
}

if(isset($_POST['quid']))
{
?>	<script>

	
	if(confirm("Are you sure  delete the table"))
	{
	<?php 
$del=$_SESSION['cn'].'_'.$mdl."_".$_POST['quid'].'_que';
$sql="drop table $del";
  if (!$con->query($sql) == TRUE) 
			echo "Error del: " . $con->connect_error;
$del=$_SESSION['cn'].'_'.$mdl."_".$_POST['quid'].'_res';
$sql="drop table $del";
if (!$con->query($sql) == TRUE) 
			echo "Error del: " . $con->connect_error;
$sql="delete from $tn where qname='$_POST[quid]'";
if (!$con->query($sql) == TRUE) 
			echo "Error del: " . $con->connect_error;

?>
	}
	else
	{
		
	}
	</script>
<?php }
if(isset($_POST['add']))
{
	
	$sql = "SELECT *FROM $tn where qname='$_POST[qnme]'";
    $result = mysqli_query($con, $sql);
	if (mysqli_num_rows($result) > 0) 
	{
  
		?><script>	alert("quiz already exist enter new");</script> <?php
	}
	else
	{
	$sql = "insert into $tn(qname,dis,pub,qtype)values('$_POST[qnme]','$_POST[dis]',0,'$_POST[qt]')";
   if (!$con->query($sql) == TRUE) 
    echo "Error create: " . $con->connect_error;
	else
	{
		$na=$_SESSION['cn'].'_'.$mdl.'_'.$_POST['qnme'].'_que';
		
		$sql="CREATE TABLE $na(qid int auto_increment,primary key(qid),ques varchar(1000),ans int,op1 varchar(100),op2 varchar(100),op3 varchar(100),op4 varchar(100),expl varchar(1000));";
		if (!$con->query($sql) == TRUE) 
			echo "Error del: " . $con->connect_error;
		
		$na=$_SESSION['cn'].'_'.$mdl.'_'.$_POST['qnme'].'_res';
		
		$sql="create table $na(no int auto_increment,primary key(no),uname varchar(40),tot int,tim DATETIME on update CURRENT_TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP)";
		if (!$con->query($sql) == TRUE) 
			echo "Error del: " . $con->connect_error;
		
		if($_POST['qt']=='Live')
		{	
			$na=$_SESSION['cn'].'_'.$mdl.'_'.$_POST['qnme'].'_que';
			$sql="alter table $na add(pub int)";
		
		if (!$con->query($sql) == TRUE) 
			echo "Error create: " . $con->connect_error;
		
		$na=$_SESSION['cn'].'_'.$mdl.'_'.$_POST['qnme'].'_res';
		$sql="select *from $ts";
		$result = $con->query($sql);
		if ($result->num_rows > 0) 
		{
			while($row = $result->fetch_assoc())
			{
				$sql1="insert into $na(uname) values ('$row[sname]')";
				if (!$con->query($sql1) == TRUE) 
					echo "Error del: " . $con->connect_error;
				
			}

		}
		}
	}
}
}

 if($_SESSION["ty"]=="tec")
  {?>
 <button onclick="myFunction('Demo1')" class="w3-button w3-block w3-left-align">
+Add Quiz</button>

<div id="Demo1" class="w3-container w3-hide">
<form  method="post" class="w3-container">

<label class="w3-text-blue"><b>Add Quiz</b></label>
<input class="w3-input w3-border" name="qnme" type="text">
<label class="w3-text-blue"><b>Discription</b></label>
<input class="w3-input w3-border" name="dis" type="text">
 

      <input class="with-gap" name="qt" value="Post" type="radio" id="sme" required />
      <label for="sme">Post</label>
    
      <input class="with-gap" name="qt" value="Live" type="radio" id="sbn" />
      <label for="sbn">Live</label>
   
	<button class="w3-btn w3-blue" name="add" value="add" >Add</button>
</form>
</div>
   <?php
  }

  if($_SESSION["ty"]=="tec")
  	$sql = "select *from $tn";
  else
	  $sql = "select *from $tn where pub=1";
  $result = $con->query($sql);
?>
<form method="post">
<?php 

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {?>



<div class="w3-panel  w3-round w3-border w3-border-red w3-hover-border-green">
<h3 class="w3-text-orange"/>
<?php  echo $row["qname"];?>
<div class="w3-right-align">
<?php 
if($row['qtype']=='Post')	
{ 
?>
<button class="w3-button w3-round w3-orange w3-text-white" value="<?php echo $row["qname"]?>" name="qui">Enter</button>	
<?php
}
else
{
?>
<button class="w3-button w3-round w3-orange w3-text-white" value="<?php echo $row["qname"]?>" name="quilve">Enter</button>		
<?php 
}
	if($_SESSION["ty"]=="tec")
	{
	if($row['qtype']=='Post')	
	{ 
	if($row['pub']==0) { ?>
	<button class="w3-button w3-round w3-orange w3-text-white" value="<?php echo $row["qname"]?>" name="quil">Launch</button> <?php } ?>
	<?php
	}
	else
	{
		if($row['pub']==1)
		{ ?>
		<button class="w3-button w3-round w3-orange w3-text-white" value="<?php echo $row["qname"]?>" name="quih">hide</button>
		<?php 
		}
		else
		{ ?>
		<button class="w3-button w3-round w3-orange w3-text-white" value="<?php echo $row["qname"]?>" name="quillve">Launch</button>	
		<?php 
		}
	}
	?>
	<button class="w3-button w3-round w3-red w3-text-white" value="<?php echo $row["qname"]?>" name="quid">&times </button>
	<?php 
	}
	?>	</div>	</div>
  
		
<?php  }  }
 else 
    echo "0 results";

  ?>  
</form>        
  		
    </body>
</html>
