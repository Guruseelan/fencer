  <html>
  <head>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.98.2/css/materialize.min.css">

  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.98.2/js/materialize.min.js"></script>
  </head>
  <body>
  
     <div class="row ">
      <div class="card-panel #42a5f5 blue lighten-1"><h5 class="center-align">Admin</h5></div>
      <div class="col s12 m4 l3 "> <!-- Note that "m4 l3" was added -->
      <div class="collection">
    <a href="home.php" target="fra" class="collection-item">Home</a>
    <a href="people.php" target="fra" class="collection-item">Add People</a>
    <a href="ans.php" target="fra" class="collection-item">none</a>
    <a href="#!" class="collection-item">none</a>
    </div>

      </div>
      <div class="col s12 m8 l9 "> <!-- Note that "m8 l9" was added -->
	  <iframe src="home.php" name="fra" height="500" width="650"></iframe>
	
        <!-- Teal page content

              This content will be:
          9-columns-wide on large screens,
          8-columns-wide on medium screens,
          12-columns-wide on small screens  -->

      </div>

  
     </div>      
</body>
</html>