<?php
	session_start();
	if(!isset($_SESSION["ty"]))
	header("location:logout.php");
	$con=new mysqli('localhost','root','',"ding");
?>
<!DOCTYPE html>
<html>
    <head>
       <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
	   
	   <link rel="stylesheet" href="css/w3m.css">
	    <link rel="stylesheet" href="css/w3.css">
       <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	
      <script type="text/javascript" src="js/materialize.min.js"></script>
	  <script type="text/javascript" src="js/materialize.js"></script>
	  
	  
<script>
function myFunction(id) {
    var x = document.getElementById(id);
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}
</script>
	
  </head>
    <body>

<?php

if(isset($_POST['add']))
{
   if(empty($_POST["ckarr"]))
      echo("You didn't select any people.");
  else
  {
	$sql="select cname from course where ccode='$_SESSION[cn]'";
	$res=mysqli_query($con,$sql);
	$row=mysqli_fetch_array($res);
	$tt=$row['cname'];
	
	mysqli_query($con,$sql);$arr = $_POST["ckarr"];
    $N = count($arr);
    $tn=$_SESSION["cn"]."_std";
    $N = count($arr);
    for($i=0; $i < $N; $i++)
	{
    $sql="insert into $tn (sname) values ('$arr[$i]')";
	mysqli_query($con,$sql);
   }
    for($i=0; $i < $N; $i++)
	{
    $sql="insert into stdcou (uname,cname,ccode) values ('$arr[$i]','$tt','$_SESSION[cn]')";
	mysqli_query($con,$sql);
   }
  }
}
  if($_SESSION["ty"]=="tec")
  {?>
 <button onclick="myFunction('Demo1')" class="w3-button w3-block w3-left-align">
+Add People</button>

<div id="Demo1" class="w3-container w3-hide">
<form method="post">
	
 <?php
 
	$tn=$_SESSION["cn"]."_std";
   $sql = "select *from stud where uname not in (select sname from $tn)";
   $result = $con->query($sql);
   if ($result->num_rows > 0) {
	   
    while($row = $result->fetch_assoc()) {?>
       
		<input type="checkbox" name="ckarr[]" value="<?php echo $row["uname"];?>" id="<?php echo $row["uname"];?>"/>
      <label for="<?php echo $row["uname"];?>"><?php echo $row["uname"]."  -   ".$row["sname"];?></label><br>
       
      <?php    }
}
 else {
    echo "0 results";
}
  ?>
<input type="submit" name="add" value="Submit" />

    </form>  
</div>
  <?php } ?>
<div class="w3-container">
    <table class="w3-table-all w3-card-4">
    <tr>
      <th>User Name</th>
      <th>Points</th>
    </tr>
 <?php
  
  $tn=$_SESSION["cn"]."_std";
   $sql = "select *from $tn";
   $result = $con->query($sql);
   if ($result->num_rows > 0) {
	   
    while($row = $result->fetch_assoc()) {
       
		
		?>
      <tr>
     
      <td><?php echo $row["sname"]; ?></td>
	   <td>0</td>
    </tr>
       
  <?php    }
}
 else {
    echo "0 results";
}
	?>
  </table>
</div>
    </body>
</html>
