<?php
	session_start();
	if(!isset($_SESSION["ty"]))
			header("location:logout.php");
	$con=new mysqli('localhost','root','',"ding");

?>
<html>
    <head>
        <meta charset="UTF-8">

 
     <link rel="stylesheet" href="css/w3m.css">
	 <link rel="stylesheet" href="css/w3.css">
	 
	
      <script type="text/javascript" src="js/materialize.min.js"></script>
	  <script type="text/javascript" src="js/materialize.js"></script>
	   	<script src="js/init.js"></script>
		  <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
 <script>

</script>
 </head>
<body>
  <body>
 

  <div class="w3-bar w3-white">
<?php  
	if($_SESSION["ty"]=="tec")
	{?>
    <a href="r1.php" target="sfra" class="w3-bar-item w3-button w3-hover-blue">Add Question</a>
	
    <a href="r2.php" target="sfra" class="w3-bar-item w3-button w3-hover-blue">Result</a><?php } ?>
    <a href="lboard.php" target="sfra" class="w3-bar-item w3-button w3-hover-blue">Score Card</a>
  </div>


  <iframe src="lboard.php" name="sfra" height="100%" width="100%"></iframe>


	</body>
	</html>