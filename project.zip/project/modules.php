<?php
	session_start();
	if(!isset($_SESSION["ty"]))
	header("location:logout.php");
	$con=new mysqli('localhost','root','',"ding");

?>
<html>
    <head>
        <meta charset="UTF-8">

 
     <link rel="stylesheet" href="css/w3m.css">
	 <link rel="stylesheet" href="css/w3.css">
	 
	
      <script type="text/javascript" src="js/materialize.min.js"></script>
	  <script type="text/javascript" src="js/materialize.js"></script>
	   	<script src="js/init.js"></script>
		  <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
 <script>

</script>
 </head>
<body>
  <body>
 

  <div class="w3-bar w3-white">
<?php  
	if($_SESSION["ty"]=="tec")
	{?>
    <a href="p1.php" target="mfra" class="w3-bar-item w3-button w3-hover-blue">Add Question</a>
	<?php } ?>
    <a href="p2.php" target="mfra" class="w3-bar-item w3-button w3-hover-blue">Quiz</a>
    <a href="ans.php" target="mfra" class="w3-bar-item w3-button w3-hover-blue">Answer</a>
    <a href="lboard.php" target="mfra" class="w3-bar-item w3-button w3-hover-blue">Score Card</a>
  </div>


  <iframe src="p2.php" name="mfra" height="100%" width="100%"></iframe>


	</body>
	</html>