<?php
session_start();
	if(!isset($_SESSION["ty"]))
		header("location:logout.php");
		$res=0;
		$con=new mysqli('localhost','root','',"ding");
		$na="mahaswty5@gmail.com";//$_SESSION["uname"];
		
		$sql = "select ccode from stdcou where uname='$na'";
	
		$result = $con->query($sql);
		if ($result->num_rows > 0) 
		{
			while($row = $result->fetch_assoc()) 
		{		
		$cnm=$row['ccode'];
		
		$sql1="select *from swift where ccode='$cnm'";
		$result1 = $con->query($sql1);
		if ($result1->num_rows > 0) 
		{
			while($row1= $result1->fetch_assoc()) 
		{
		$swq=$row1['ccode'].'_'.$row1['mdl'].'_'.$row1['que'].'_que';
		$swr=$row1['ccode'].'_'.$row1['mdl'].'_'.$row1['que'].'_res';
		$sql2="select *from $swq where pub=1";
		$result2 = $con->query($sql2);
		if ($result2->num_rows > 0) 
		{
			while($row2= $result2->fetch_assoc()) 
		{
				$qi='q'.$row2['qid'];
				$sql3="select *from $swr where $qi is null and uname='$na'";
				$result3 = $con->query($sql3);
				if ($result3->num_rows > 0) 
				{
				$res++;
				}
		}
		}
		}
		}
		}
		}
		echo $res;
		?>