<?php
	session_start();
	$con=new mysqli('localhost','root','',"ding");
?><html>
    <head>
        <meta charset="UTF-8">

   <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
     <link rel="stylesheet" href="css/w3m.css">
	  <link rel="stylesheet" href="css/w3.css">
<script>
function myFunction(id) {
    var x = document.getElementById(id);
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}
	
</script>
 </head>
<body>

<?php

if(isset($_POST['ch']))
{
	
	$_SESSION["cn"]=$_POST['ch'];
	header("location:content.php");
}

if(isset($_POST['add']))
{
	
	$sql = "SELECT *FROM course where cname='$_POST[cnme]' or ccode='$_POST[cde]'";
    $result = mysqli_query($con, $sql);
	if (mysqli_num_rows($result) > 0) 
	{
  
		?><script>	alert("course already exist enter new name");</script> <?php
	}
	else
	{
	$sql = "insert into course(cname,uname,ccode,dis)values('$_POST[cnme]','$_SESSION[uname]','$_POST[cde]','$_POST[dis]')";
	if (!$con->query($sql) == TRUE) 
    echo "Error create: " . $con->connect_error;
	else
	{
		$na=$_POST['cde'].'_std';
		$sql="create table $na(no int auto_increment,primary key(no),sname varchar(40))";
		if (!$con->query($sql) == TRUE) 
			echo "Error del1: " . $con->con->error;
		$na=$_POST['cde'].'_mdl';

		$sql="create table $na(no int auto_increment,primary key(no),mname varchar(40),dis varchar(200))";
		if (!$con->query($sql) == TRUE) 
			echo "Error del2: " . $con->con->error;
		
	}
	}

}
?>
<div class="w3-panel w3-border-top w3-border-bottom">
<h3>All Courses</h3>
</div>  <?php 
 if($_SESSION["ty"]=="tec")
  {?>
 <button onclick="myFunction('Demo1')" class="w3-button w3-block w3-left-align">
+Add Course</button>

<div id="Demo1" class="w3-container w3-hide">
<form  method="post" class="w3-container">

<label class="w3-text-blue"><b>Course Name</b></label>
<input class="w3-input w3-border" name="cnme" type="text">

<label class="w3-text-blue"><b>Course Code</b></label>
<input class="w3-input w3-border" name="cde" type="text">

<label class="w3-text-blue"><b>Discription</b></label>
<input class="w3-input w3-border" name="dis" type="text">
 <button class="w3-btn w3-blue" name="add" value="add" >Add</button>
 
</form>
</div>
   <?php } 
 
if($_SESSION["ty"]=="tec")
	$sql = "select *from course where uname='$_SESSION[uname]'";
else
	$sql = "select *from stdcou where uname='$_SESSION[uname]'";
   $result = $con->query($sql);?>
<div class="row">
           
            <div class="col s12 m12">
            
<form method="post">
<?php 

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {?>
	
	  <div class="col s12 m7">
       <div class="card horizontal">
      <div class="card-image">
        <img src="book.png">
      </div>
      <div class="card-stacked">
      
        <div class="card-action">
           <button class="w3-button w3-block w3-left-align w3-blue" value="<?php echo $row["ccode"]?>" name="ch"><?php  echo $row["cname"]?></button><br>
        </div>
      </div>
    </div>
  </div>
  
       
		
 <?php    }
}
 else {
    echo "0 results";
}
	?>	
	</form></div>
		




</div>

       
	</body>
	</html>