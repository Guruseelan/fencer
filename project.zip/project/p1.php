<?php
	session_start();
	if(!isset($_SESSION["ty"]))
	header("location:logout.php");
$con=new mysqli('localhost','root','',"ding");
$tq=$_SESSION['cn'].'_'.$_SESSION['mdl'].'_'.$_SESSION['qn'].'_que';
?>
<html>
<head>
   <meta charset="UTF-8">

   <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
     <link rel="stylesheet" href="css/w3.css">
     <style>
	 body {
	 background-color:rgb(255,255,255);}
	 textarea {
    width:850px;
	height:100px;
    padding: 3px;
    border: none;
    }
	      
	 </style>
	 <script>
function myFunction(id) {
    var x = document.getElementById(id);
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}
	
</script>
</head>
<body>
<?php 
if(isset($_POST['add']))
{

	$ques=$_POST['ques'];
	$ans=$_POST['ans'];
	$op1=$_POST['op1'];
	$op2=$_POST['op2'];
	$op3=$_POST['op3'];
	$op4=$_POST['op4'];
	$ex=$_POST['exp'];
	$sql="insert into $tq(ques,ans,op1,op2,op3,op4,expl) values('$ques','$ans','$op1','$op2','$op3','$op4','$ex')";
	mysqli_query($con,$sql);
	}
?>


<div class="row">

<div class="card-panel">
<form method="post" class="w3-container">
question <textarea class="w3-input w3-border" name="ques" required ></textarea>

Answer<input type="text" class="w3-input w3-border" name="ans" required>


 

  
 <div class="w3-row-padding">
 <div class="w3-half">
<textarea class="w3-input w3-border" name="op1" required placeholder="Option 1" ></textarea>
</div>
 <div class="w3-half">
 <textarea class="w3-input w3-border" name="op2" required placeholder="Option 2" ></textarea>
</div>
</div>
 <div class="w3-row-padding">
 <div class="w3-half">
 <textarea class="w3-input w3-border" name="op3" required placeholder="Option 3" ></textarea>
</div>
 <div class="w3-half">
 <textarea class="w3-input w3-border" name="op4" required placeholder="Option 4" ></textarea>
  </div></div> </div>

Explanation<textarea class="w3-input w3-border" name="exp" required></textarea>
<div class="card-action"><button name="add">ADD</button></div>

</div>
</form></div>











 <button onclick="myFunction('Demo1')" class="w3-button w3-block w3-left-align">
Show Question</button>

<div id="Demo1" class="w3-container w3-hide">
<?php


	$sql = "select *from $tq";
   $result = $con->query($sql);
   if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {?>
        <tr>
            <td><?php echo $row['qid'];?></td><br>
            <td><?php echo  nl2br($row['ques']);?></td><br>
			<td><?php echo "Option: ". $row['ans'];?></td>
            
          </tr>
		  <br>
      <?php    }
}
 else {
    echo "0 results";
}
	?>
        </tbody>
      </table>
            
</div>
</body></html>