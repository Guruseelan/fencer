<?php 
  $i=1;
session_start();
if(!isset($_SESSION["ty"]))
	header("location:logout.php");
$con=new mysqli('localhost','root','',"ding");
$tq=$_SESSION['cn'].'_'.$_SESSION['mdl'].'_'.$_SESSION['qn'].'_que';
$tr=$_SESSION['cn'].'_'.$_SESSION['mdl'].'_'.$_SESSION['qn'].'_res';
?>
<html>
<head>
   <meta charset="UTF-8">

   <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
     <link rel="stylesheet" href="css/w3.css">
     <style>
	 body {
	 background-color:rgb(255,255,255);}
	 h3{
  font-family: "Comic Sans MS", cursive, sans-serif;
}
	      
	 </style>
	 <script>
function myFunction(id) {
    var x = document.getElementById(id);
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}
	
</script>
</head>
<body>



<?php
if(isset($_POST['Submit']))
{
   if(empty($_POST["o"]))
      echo("Attend All");
  else
  {
	$arr = $_POST["o"];
	//$tn=$_SESSION["qn"] . '_que';
	$sql="select * from $tq";
	$result= mysqli_query($con, $sql);
	$j=1;
	$score=0;
	while($row=mysqli_fetch_array($result))
	{
		if(strcmp($row['ans'],$arr[$j])==0)
		 $score++; 
		$j++;
	}
	//$tn=$_SESSION["qn"] . '_res';
	$tt=$_SESSION['uname'];
	$sql="select * from $tr where uname='$tt'";
	$result = mysqli_query($con, $sql);
	if (mysqli_num_rows($result) > 0) 
	{
  
		?><script>	alert("<?php echo "Already Submitted! Your Score: ". $score; ?>");</script> <?php
	}
	else
	{
		$sql="insert into $tr (uname,tot) values ('$tt','$score')";
		mysqli_query($con, $sql);
		?><script>	alert("<?php echo "Your Score: ". $score; ?>");</script> <?php
    }
	header("location:lboard.php");
  }
}
?>
<div class="w3-panel w3-border w3-border-red">
  <h3><?php echo $_SESSION["qn"];?></h3>
  <p>Attend All Questions... Unless Cannot Submit!</p>
</div>
<form method="post">
<div class="w3-container">
  <form method="post">
  <?php
//$tn=$_SESSION["qn"] . '_que';
$sql="select * from $tq";
$result= mysqli_query($con, $sql);
 while($row=mysqli_fetch_array($result))
{
	?><div class="w3-panel w3-border">
	  <div class="w3-panel w3-border-bottom">
  <h3><?php echo "Question ".$i;?></h3>
</div>
  <div class="w3-panel w3-border-bottom">
  <p><?php echo nl2br(htmlspecialchars($row['ques']));?></p>
</div>

    <p>
      <input class="with-gap" name="o[<?php echo $i;?>]" value="1" type="radio" id="<?php echo'a'.$i;?>" required />
      <label for="<?php echo'a'.$i;?>"><?php echo nl2br(htmlspecialchars($row['op1']));?></label>
    </p>
    <p>
      <input class="with-gap" name="o[<?php echo $i;?>]" value="2" type="radio" id="<?php echo'b'.$i;?>" />
      <label for="<?php echo'b'.$i;?>"><?php echo nl2br(htmlspecialchars($row['op2']));?></label>
    </p>
    <p>
      <input class="with-gap" name="o[<?php echo $i;?>]" value="3" type="radio" id="<?php echo'c'.$i;?>" />
      <label for="<?php echo'c'.$i;?>" ><?php echo nl2br(htmlspecialchars($row['op3']));?></label>
    </p>
    <p>
      <input class="with-gap" name="o[<?php echo $i;?>]" value="4" type="radio" id="<?php echo'd'.$i;?>"  />
      <label for="<?php echo'd'.$i;?>"><?php echo nl2br(htmlspecialchars($row['op4']));?></label>
    </p><br></div>
<?php
	$i++;
}?>
<button  name="Submit" value="Submit">Submit</button?
  </form>
  </div>
  </div>
  </body>
  </html>