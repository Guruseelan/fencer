<?php
session_start();
if(!isset($_SESSION["ty"]))
	header("location:logout.php");
$con = new mysqli('localhost','root','','ding');
?>
<html>
<head>
<meta charset="UTF-8">
<link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
<link rel="stylesheet" href="css/w3m.css">
  <link rel="stylesheet" href="css/w3.css">
  
  <script>
function w3_open() {
  document.getElementById("main1").style.marginLeft = "25%";
  document.getElementById("mySidebar").style.width = "25%";
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("openNav").style.display = 'none';
}
function w3_close() {
  document.getElementById("main1").style.marginLeft = "0%";
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("openNav").style.display = "inline-block";
}

</script>
</head>
<body>

<div class="white   w3-card-4 ">
  
<button class="w3-button white  w3-xlarge" onclick="w3_open()">
<a class="btn btn-floating pulse #ef6c00 orange">&#9776;</a></button><?php echo $_SESSION["cn"];?>
<div class="w3-sidebar w3-bar-block w3-card-2 w3-animate-left" style="display:none" id="mySidebar"> 
<button class="w3-bar-item w3-button w3-large"
onclick="w3_close()">MODULES  &times;</button>
 <?php 
 if($_SESSION["ty"]=="tec")
  {?>
 <button onclick="document.getElementById('id01').style.display='block'" class="w3-button w3-block w3-left-align w3-green">Add Module</button>
  <?php } 
$tn=$_SESSION['cn'].'_mdl';
$sql = "select *from $tn";
$result = $con->query($sql);
if(isset($_POST['add']))
{
	$sql = "SELECT *FROM $tn where mname='$_POST[mnme]'";
    $result = mysqli_query($con, $sql);
	if (mysqli_num_rows($result) > 0) 
	{
  
		?><script>	alert("module already exist enter new name");</script> <?php
	}
	else
	{
	$sql = "insert into $tn(mname,dis)values('$_POST[mnme]','$_POST[dis]')";
	if (!$con->query($sql) == TRUE) 
    echo "Error crt: " . $con->connect_error;
	else
	{
		$na=$_SESSION['cn'].'_'.$_POST['mnme'].'_cnt';

		$sql="create table $na(no int auto_increment,primary key(no),qname varchar(20),dis varchar(200),pub int);";
		if (!$con->query($sql) == TRUE) 
			echo "Error del2: " . $con->con->error;
		
	}
	}

}
?>
<ul class="w3-ul">





<?php

$tn=$_SESSION['cn'].'_mdl';
 
$sql = "select *from $tn";
$result = $con->query($sql);  



if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {?>
  <li class="w3-hover-blue">
  <a href="quiz.php?val=<?php echo $row["mname"];?>" target="cfra" onclick="w3_close()"><u><?php echo $row["mname"];?></u></a>
		</li>
	<?php }
	}

 else {
    echo "No Modules";
}
	?>
 <li class="w3-hover">
  <a href="people.php" target="cfra" onclick="w3_close()"><u>People</u></a>
</li>
 <li class="w3-hover">
  <a href="r1.php" target="cfra" onclick="w3_close()"><u>Swift</u></a>
</li>
 <li class="w3-hover-red">
  <a href="home.php" onclick="w3_close()"><u>Exit</u></a>
</li>
	
</ul>
</div>
	
</div>


 <div zclass="w3-main" id="main1">

  <iframe src="home.php" name="cfra" height="90%" width="100%"></iframe>
</div> 

 
 
<div class="w3-container">
<div id="id01" class="w3-modal">
<div class="w3-modal-content w3-card-4 w3-animate-zoom" style="max-width:600px">

<div class="w3-panel w3-border-top w3-border-bottom">
<h3>Add Module</h3>
</div>

<span onclick="document.getElementById('id01').style.display='none'" class="w3-button w3-xlarge w3-hover-red w3-display-topright" title="Close Modal">&times;</span>

<form  method="post" class="w3-container">

<label class="w3-text-blue"><b>Module Name</b></label>
<input class="w3-input w3-border w3-margin-bottom" name="mnme" type="text">
<label class="w3-text-blue"><b>Discription</b></label>
<input class="w3-input w3-border" name="dis" type="text">

<div class="w3-container w3-border-top w3-padding-16 w3-light-grey">
 <button class="w3-btn w3-blue" name="add" value="add" >Add</button>  
 <button onclick="document.getElementById('id01').style.display='none'" 
 type="button" class="w3-button w3-red">Cancel</button>

</div>
</form>
</div>
</div>
</div> 	
</body>
</html>